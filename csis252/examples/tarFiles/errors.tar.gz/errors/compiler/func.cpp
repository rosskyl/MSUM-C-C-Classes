#include "circle.h"
#include <iostream>
using namespace std;

void func(Circle& c)
{
   c.setRadius(5);
}

