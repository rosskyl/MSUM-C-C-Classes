//Author:      Kyle Ross
//Assignment:  5
//Professor:   Brekke
//Due:         Oct 17, 2014
//Description: contains all constants


const int ARRAY_SIZE = 10;//max array size