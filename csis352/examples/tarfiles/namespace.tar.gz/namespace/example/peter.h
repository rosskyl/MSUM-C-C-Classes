// file: peter.h
namespace peter
{
   void read();
   void write();
};
