#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_
const int MAX_ITEMS = 100000;
#endif
