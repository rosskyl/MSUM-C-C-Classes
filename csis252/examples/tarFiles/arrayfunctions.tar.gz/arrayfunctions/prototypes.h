void read(int numbers[],int& count);
void output(const int numbers[], int count);
int sum(const int numbers[], int count);
double average(const int numbers[], int count);
void sort(int numbers[], int n);
void largest(const int numbers[], int count,
             int& biggest, int& index);

