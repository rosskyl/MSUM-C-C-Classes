// prototypes for the utility functions

void function1();
void function2();
void function3();
void function4();
