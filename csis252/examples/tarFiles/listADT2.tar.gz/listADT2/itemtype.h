#ifndef _ITEMTYPE_H_
#define _ITEMTYPE_H_
#include "groceryitem.h"
typedef GroceryItem ITEM;
#endif
