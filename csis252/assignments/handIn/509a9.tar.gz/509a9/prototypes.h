//File:		prototypes.h
//Author:	Kyle Ross
//Assignment:	9
//Professor:	Brekke
//Due:		11/17/2014
//Description:	contains function prototypes


void read(arrayListType<employeeType>& employees);
void output(arrayListType<employeeType>& employees);
