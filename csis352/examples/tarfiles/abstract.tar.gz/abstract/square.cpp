#include <iostream>

using namespace std;

#include "square.h"


Square::Square(double sideValue, int xValue, int yValue)
   : Rectangle(sideValue,sideValue,xValue,yValue)
{}

