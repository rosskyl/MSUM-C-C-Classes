const int sentinel = 0;
const int arraysize = 20;
