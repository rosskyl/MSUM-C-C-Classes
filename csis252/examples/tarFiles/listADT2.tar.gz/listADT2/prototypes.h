int menu();
void addItem(arrayListType&);
void deleteItem(arrayListType&);
int totalItems(const arrayListType&);
void totalOfItem(const arrayListType&);
