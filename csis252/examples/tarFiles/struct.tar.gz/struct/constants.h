// File:    constants.h
// Author:  Dan Brekke
// Date:    
// Class:   CSIS 252
// Program: class example

// Description
// This file contains the contant declarations

const int maxstudents = 100;  // the maximum number of students
