//File:		constants.h
//Author:      Kyle Ross
//Assignment:  6
//Professor:   Brekke
//Due:         Oct 24, 2014
//Description:	contains all constants


int const ARRAY_SIZE = 100;//max array size

double const FED_TAX_RATE = 0.3;//federal tax rate

double const SOC_SEC_RATE = 0.08;//social security tax rate