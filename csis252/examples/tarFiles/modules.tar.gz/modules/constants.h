// File:    constants.h
// Author:  Dan Brekke
// Program: class example
// Date:    

// Description: This file contains constant declarations

const int arraysize=5;  // the size of the array
