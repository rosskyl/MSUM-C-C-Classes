// file: stewie.cpp
#include <iostream>
#include "stewie.h"
using namespace std;

namespace stewie
{

void read()
{
   cout << "This is Stewie's read function\n";
}

void write()
{
   cout << "This is Stewie's write function\n";
}

}
